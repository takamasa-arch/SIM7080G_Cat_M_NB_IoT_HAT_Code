#ifndef __SIM7800G_H_
#define __SIM7800G_H_

#include "main.h"

#define CSQ								"AT+CSQ\r\n"
#define QUERY_CPSI				"AT+CPSI?\r\n"
#define EN_CNACT					"AT+CNACT=0,1\r\n"
#define CACID							"AT+CACID=0\r\n"
#define CAOPEN						"AT+CAOPEN=0,0,\"TCP\",\"116.30.219.149\",5001\r\n"
#define CASEND						"AT+CASEND=0,17,2000\r\n"
#define MESSAGES					"www.waveshare.com"
#define CACLOSE						"AT+CLOSE=0\r\n"
#define DIS_CNCAT					"AT+CNACT=0,0\r\n"

void power_dowm(void);
void power_up(void);
void send_at(char *s_buf1,char*s_buf2,uint8_t com1length,uint8_t com2length,uint8_t command_num,uint16_t delay_ms);
void tcp_test(void);

#endif

