#include "sim7080g.h"
#include "string.h"
#include "usart.h"

void power_dowm(void)
{
	HAL_GPIO_WritePin(PWRKEY_GPIO_Port,PWRKEY_Pin,GPIO_PIN_SET);
	HAL_Delay(2000);
	HAL_GPIO_WritePin(PWRKEY_GPIO_Port,PWRKEY_Pin,GPIO_PIN_RESET);
	HAL_Delay(2000);
}

void power_up(void)
{
	HAL_GPIO_WritePin(PWRKEY_GPIO_Port,PWRKEY_Pin,GPIO_PIN_SET);
	HAL_Delay(2000);
	HAL_GPIO_WritePin(PWRKEY_GPIO_Port,PWRKEY_Pin,GPIO_PIN_RESET);
	HAL_Delay(2000);
}

void send_at(char *s_buf1,char*s_buf2,uint8_t com1length,uint8_t com2length,uint8_t command_num,uint16_t delay_ms)
{
	char * p_ok;
	
	if(1 == command_num){
		HAL_UART_Transmit(&huart1,(uint8_t *)s_buf1,com1length,0xff);
		HAL_Delay(1000);
		if(UsartType.RX_flag){  
			UsartType.RX_flag=0;
			p_ok = strstr((char *)UsartType.RX_pData,"OK");
			HAL_UART_Transmit(&huart2, UsartType.RX_pData, UsartType.RX_Size, 0xFFFF);
		}
		if(NULL != p_ok){
			
		}else{
			HAL_UART_Transmit(&huart2, UsartType.RX_pData, UsartType.RX_Size, 0xFFFF);
		}
	}else if(2 ==command_num){
		HAL_UART_Transmit(&huart1,(uint8_t *)s_buf1,com1length,0xff);
		HAL_Delay(1000);
		HAL_UART_Transmit(&huart1,(uint8_t *)s_buf2,com2length,0xff);
		HAL_Delay(2100);
		if(UsartType.RX_flag){  
			UsartType.RX_flag=0;
			p_ok = strstr((char *)UsartType.RX_pData,"OK");
			HAL_UART_Transmit(&huart2, UsartType.RX_pData, UsartType.RX_Size, 0xFFFF);
		}
		if(NULL != p_ok){
			
		}else{
			HAL_UART_Transmit(&huart2, UsartType.RX_pData, UsartType.RX_Size, 0xFFFF);
		}
	}
	HAL_Delay(delay_ms);
	
}

void tcp_test(void)
{
	power_up();
	HAL_UART_Transmit(&huart2,(uint8_t *)"\r\nwait 15 seconds for signal\r\n\r\n",sizeof("\r\nwait 15 seconds for signal\r\n\r\n")-1,0xff);
	HAL_Delay(15000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)CSQ,sizeof(CSQ)-1,0xff);
	send_at(CSQ,NULL,sizeof(CSQ)-1,0,1,1000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)QUERY_CPSI,sizeof(QUERY_CPSI)-1,0xff);
	send_at(QUERY_CPSI,NULL,sizeof(QUERY_CPSI)-1,0,1,1000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)EN_CNACT,sizeof(EN_CNACT)-1,0xff);
	send_at(EN_CNACT,NULL,sizeof(EN_CNACT)-1,0,1,1000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)CACID,sizeof(CACID)-1,0xff);
	send_at(CACID,NULL,sizeof(CACID)-1,0,1,1000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)CAOPEN,sizeof(CAOPEN)-1,0xff);
	send_at(CAOPEN,NULL,sizeof(CAOPEN)-1,0,1,1000);
	
	HAL_UART_Transmit(&huart2,(uint8_t *)CASEND,sizeof(CASEND)-1,0xff);
	HAL_UART_Transmit(&huart2,(uint8_t *)MESSAGES,sizeof(MESSAGES)-1,0xff);
	HAL_UART_Transmit(&huart2,(uint8_t *)"\r\n",2,0xff);
	send_at(CASEND,MESSAGES,sizeof(CASEND)-1,sizeof(MESSAGES)-1,2,1000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)CACLOSE,sizeof(CACLOSE)-1,0xff);
	send_at(CACLOSE,NULL,sizeof(CACLOSE)-1,0,1,1000);
	
//	HAL_UART_Transmit(&huart2,(uint8_t *)DIS_CNCAT,sizeof(DIS_CNCAT)-1,0xff);
	send_at(DIS_CNCAT,NULL,sizeof(DIS_CNCAT)-1,0,1,1000);
	power_dowm();
}


